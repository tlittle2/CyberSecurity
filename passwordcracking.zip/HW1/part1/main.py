import getpass
import sys
import hashlib
import string
import math


def make_pw_hash(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

def calculateEntropy(password):
    s = 0
    punc = False
    lower = False
    upper = False
    digit = False
    for i in password:
        if i in string.digits:
            digit = True
        elif i in string.ascii_lowercase:
            lower = True
        elif i in string.ascii_uppercase:
            upper = True
        elif i in string.punctuation:
            punc = True

    if digit:
        s += len(string.digits)
    if upper:
        s += len(string.ascii_uppercase)
    if lower:
        s += len(string.ascii_lowercase)
    if punc:
        s += len(string.punctuation)

    return math.log2(s ^ len(password))

def main():
    file = open("../passwords.txt", "w")

    for i in range(10):
        print("Enter your username: ")
        u = sys.stdin.readline().strip()
        #print("Enter your password: ")
        #p = sys.stdin.readline().strip()
        p = getpass.getpass(prompt="Enter a password: ")
        print(calculateEntropy(p))
        h = make_pw_hash(p)
        file.write(u + ":" + str(h) + "\n")
        print("\n")
    file.close()

if __name__ == '__main__':
    main()
