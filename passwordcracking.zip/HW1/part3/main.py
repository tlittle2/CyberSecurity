import hashlib
import time
import string
import math

dict = {
    "s": "$",
    "l": "1",
    "a": "@",
    "e": "3",
    "O": "0",
    "o": "0"
}


def make_pw_hash(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

def calculateEntropy(password):
    s = 0
    punc = False
    lower = False
    upper = False
    digit = False
    for i in password:
        if i in string.digits:
            digit = True
        elif i in string.ascii_lowercase:
            lower = True
        elif i in string.ascii_uppercase:
            upper = True
        elif i in string.punctuation:
            punc = True

    if digit:
        s += len(string.digits)
    if upper:
        s += len(string.ascii_uppercase)
    if lower:
        s += len(string.ascii_lowercase)
    if punc:
        s += len(string.punctuation)

    return math.log2(s ^ len(password))


def sortedLength(file):
    sortedFile = open("../sorted.txt", "w")
    newFile = sorted(file, key=len)
    for i in newFile:
        sortedFile.write(i)
    sortedFile.close()
    return


def replace(count):
    if count == 1:
        inputFile = open("../sorted.txt", "r")
        outputFile = open("../dict1.txt", "w")
        outputFile.truncate()
    else:
        inputFile = open("../dict1.txt", "r")
        outputFile = open("../dict2.txt", "w")
        outputFile.truncate()

    for i in inputFile:
        if i.count("s") > 0:
            outputFile.write(i.replace("s", "$", 1))
        if i.count("e") > 0:
            outputFile.write(i.replace("e", "3", 1))
        if i.count("O") > 0:
            outputFile.write(i.replace("O", "0", 1))
        if i.count("a") > 0:
            outputFile.write(i.replace("a", "@", 1))
        if i.count("l") > 0:
            outputFile.write(i.replace("l", "1", 1))

    inputFile.close()
    outputFile.close()


def dictAttack(ourHash, trial):
    if trial == 0:
        wordList = open("../sorted.txt", "r")

    if trial == 1:
        wordList = open("../dict1.txt", "r")

    if trial == 2:
        wordList = open("../dict2.txt", "r")

    tic = time.time()
    found = None
    for i in wordList:
        i = i.strip()
        # print(i)
        if make_pw_hash(i) == ourHash:
            found = i
            break
    toc = time.time()

    return found, toc - tic


def main():
    words = open("../dict.txt", "r")
    # w1R= open("../dict1.txt", "r")
    # w2R= open("../dict2.txt", "r")

    tic = time.time()
    sortedLength(words)

    replace(1)
    replace(2)

    print("Inside dict attack")
    with open("../passwords.txt", "r") as passwords:
        for line in passwords:
            tic = time.time()
            temp = line.strip()
            start = temp.find(":") + 1
            ourHash = temp[start::]

            pw = dictAttack(ourHash, 0)
            if pw[0] is not None:
                print(pw)
                print("Entropy: %s " %calculateEntropy(pw[0]))
    passwords.close()

    print()
    print("Inside first replacement attack")
    with open("../passwords.txt", "r") as passwords:
        for line in passwords:
            temp = line.strip()
            start = temp.find(":") + 1
            ourHash = temp[start::]

            pw = dictAttack(ourHash, 1)
            if pw[0] is not None:
                print(pw)
                print("Entropy: %s " % calculateEntropy(pw[0]))
    passwords.close()

    print()
    print("Inside second replacement attack")
    with open("../passwords.txt", "r") as passwords:
        for line in passwords:
            temp = line.strip()
            start = temp.find(":") + 1
            ourHash = temp[start::]

            pw = dictAttack(ourHash, 2)
            if pw[0] is not None:
                print(pw)
                print("Entropy: %s " %calculateEntropy(pw[0]))
    passwords.close()
    toc = time.time()

    print()
    print()
    print("OVERALL TIME: " + str(toc - tic))


if __name__ == '__main__':
    main()
