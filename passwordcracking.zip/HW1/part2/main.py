import hashlib
import string
import time
import itertools
import math


def make_pw_hash(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

def crack(hash):
    tic = time.time()
    chars= list(string.ascii_letters + string.punctuation + string.digits)

    for j in range(16):
        combos= itertools.product(chars, repeat= j)
        #print("Attempting %s" % j)
        flag = False
        for i in combos:
            test = ''.join(map(str, i))
            #print(test, make_pw_hash)
            if make_pw_hash(test) == hash:
                flag = True
                #print(test)
                break
        if flag:
            break
    toc = time.time()

    return test, toc-tic

def calculateEntropy(password):
    s = 0
    punc = False
    lower = False
    upper = False
    digit = False
    for i in password:
        if i in string.digits:
            digit = True
        elif i in string.ascii_lowercase:
            lower = True
        elif i in string.ascii_uppercase:
            upper = True
        elif i in string.punctuation:
            punc = True

    if digit:
        s += len(string.digits)
    if upper:
        s += len(string.ascii_uppercase)
    if lower:
        s += len(string.ascii_lowercase)
    if punc:
        s += len(string.punctuation)

    return math.log2(s ^ len(password))


def main():
    with open("../passwords.txt", "r") as file:
        for line in file:
            temp= line.strip()
            start= temp.find(":") + 1
            hash= temp[start::]

            #print(hash)

            pw= crack(hash)
            print("Password: " + str(pw[0]))
            print("Time: " + str(pw[1]))
            print("Entropy: " + str(calculateEntropy(pw[0])))
            print()

    file.close()


if __name__ == '__main__':
    main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
