import sys
import string

#Affine Cipher

def decrypt(ascii):
    a = 13
    b = 7
    aInverse = 22

    ascii -= 32
    newAscii= (aInverse * (ascii - b)) % 95
    newAscii +=32

    return newAscii


def main():
    encryptedFile= open("../../Encrypted/task2_encrypted_message.txt", "r")
    decryptedFile= open("../../Decrypted/task2_decrypted_message.txt", "w")

    for i in encryptedFile:
        for j in i:
            if j == "\n":
                newChar = j
            else:
                newChar= chr(decrypt(ord(j)))
                print(newChar)

            decryptedFile.write(newChar)

    decryptedFile.close()



if __name__ == '__main__':
    main()


