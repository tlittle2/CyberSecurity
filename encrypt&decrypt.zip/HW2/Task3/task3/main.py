import sys

p = 17
a = 2
b = 2
n = 19


def pointDouble(xP, yP):
    # if x is "infinity", double 0 and return the original point
    # if x is 0 then return infinity as our x,y coordinates,

    if xP == sys.maxsize:
        return xP, yP
    if xP == 0:
        return sys.maxsize, sys.maxsize

    # else follow the algebraic equation in video and return x, y coordinates mod p
    s = ((3 * xP * xP) + a) * pow(2 * yP, -1, p)
    xR = (s * s) - (2 * xP)
    yR = s * (xP - xR) - yP

    return xR % p, yR % p


def pointAdd(xP, yP, xQ, yQ):
    # if our x,y coordinates are ever "infinity", add 0 to it (or return the other point)
    if xP == sys.maxsize and yP == sys.maxsize:
        return xQ, yQ

    if xQ == sys.maxsize and yQ == sys.maxsize:
        return xP, yP

    # if x and y values are the same do point double on one of the point x,y coordinates
    if xP == xQ and yP == yQ:
        return pointDouble(xP, yP)

    # if the x coordinates are the same, return infinity (or some huge number)
    if xP == xQ:
        return sys.maxsize, sys.maxsize

    # Follow algebraic equation in video and return the x,y coordinates mod p
    s = (yP - yQ) * pow(xP - xQ, -1, p)

    xR = s * s - (xP + xQ)

    yR = s * (xP - xR) - yP

    return xR % p, yR % p


def scalarMultiply(xP, yP, k):
    # establish copies of coordinates for a running tally of where we are in the curve
    xR = xP
    yR = yP

    # account for wrap around on the curve
    k %= n

    # if we start with the point at infinity, then nothing should happen
    if xP == sys.maxsize:
        return xP, yP

    # Identity for addition, basically add nothing if k is 0 because 0 % 19 is 19- which is at point "infinity"
    if k == 0:
        return sys.maxsize, sys.maxsize

    # perform pointAdd() k times, updating each our coordinates each time, and return at the end
    for i in range(k - 1):
        temp = pointAdd(xR, yR, xP, yP)
        xR = temp[0]
        yR = temp[1]

    return xR, yR


# Affine Cipher
def decrypt(ascii, multiple, offset):
    inverse = pow(multiple, -1, 95)

    ascii -= 32
    newAscii = (inverse * (ascii - offset)) % 95
    newAscii += 32

    return newAscii


def tempMain():
    # testing method to confirm methods work correctly
    return
    print(scalarMultiply(5, 1, 21))
    print(pointAdd(5, 1, 5, 16))
    print(pointAdd(sys.maxsize, sys.maxsize, 5, 1))
    print(pointDouble(sys.maxsize, sys.maxsize))


def main():

    # this gets multiple and offset given instructions
    beta = 2
    bob = scalarMultiply(5, 1, beta)

    alpha = 18
    alice = scalarMultiply(5, 1, alpha)

    # this will give us the same point both ways so that we can decrypt using the same multiplier and offset
    bobAlice = scalarMultiply(alice[0], alice[1], beta)
    aliceBob = scalarMultiply(bob[0], bob[1], alpha)

    encryptedFile = open("../../Encrypted/task3_encrypted_message.txt", "r")
    decryptedFile = open("../../Decrypted/task3_decrypted_message.txt", "w")

    # start decrypting
    for i in encryptedFile:
        for j in i:
            if j == "\n":
                newChar = j
            else:
                newChar = chr(decrypt(ord(j), bobAlice[0], bobAlice[1]))
                print(newChar)

            decryptedFile.write(newChar)

    decryptedFile.close()


if __name__ == '__main__':
    main()
