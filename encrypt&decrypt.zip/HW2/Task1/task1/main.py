import sys
import string

#CAESARIAN SHIFT

def decrypt(ascii):
    ascii-=32
    newAscii = (ascii - 19) %95
    newAscii +=32

    return newAscii

def main():
    encryptedFile= open("../../Encrypted/task1_encrypted_message.txt", "r")
    decryptedFile = open("../../Decrypted/task1_decrypted_message.txt", "w")
    for i in encryptedFile:
        for j in i:
            if j == "\n":
                newChar= "\n"
            else:
                newChar= chr(decrypt(ord(j)))
                print(newChar)

            decryptedFile.write(newChar)

    decryptedFile.close()

if __name__ == '__main__':
    main()


